const config = require("./config.json");
const Discord = require("discord.js");
const Attachment = require("discord.js");
const fs = require("fs");
const ms = require('ms');
const bot = new Discord.Client();
const chalk = require("chalk");

bot.commands = new Discord.Collection();
bot.aliases = new Discord.Collection();
bot.mutes = require("./storage/mutes.json");
bot.tickets = require("./storage/tickets.json");
bot.ticketcategories = require("./storage/ticketcategories.json");
bot.suggestionnumber = require("./storage/suggestionnumber.json");
bot.blacklist = require("./storage/blacklists.json");

console.log('-------------------------------Joshs-Bot--------------------------------\n\n--------------------------------------------------------------------------');

fs.readdir("./commands/", (err, files) => {
  if(err) console.log(err);
  let jsfile = files.filter(f => f.split(".").pop() === "js");
  if(jsfile.length <= 0){
    return;
  }
  jsfile.forEach((f, i) =>{
    let props = require(`./commands/${f}`);
    console.log(`${f} loaded from folder: commands`);
    bot.commands.set(props.config.name, props);
    props.config.aliases.forEach(alias => {
      bot.aliases.set(alias, props.config.name)
    })
  });
});

fs.readdir("./commands/fun/", (err, files) => {
   if(err) console.log(err);
   let jsfile = files.filter(f2 => f2.split(".").pop() === "js");
   if(jsfile.length <= 0){
     console.log("Couldn't find commands.");
     return;
   }
   jsfile.forEach((f2, i) =>{
     let props = require(`./commands/fun/${f2}`);
//     console.log(chalk.magenta(`${f2}${chalk.white(` loaded`)}`));
     bot.commands.set(props.config.name, props);
     props.config.aliases.forEach(alias => {
       bot.aliases.set(alias, props.config.name)
     })
   });
});

fs.readdir("./commands/moderation/", (err, files) => {
  if(err) console.log(err);
  let jsfile = files.filter(f3 => f3.split(".").pop() === "js");
  if(jsfile.length <= 0){
    console.log("Couldn't find commands.");
    return;
  }
  jsfile.forEach((f3, i) =>{
    let props = require(`./commands/moderation/${f3}`);
//    console.log(chalk.blueBright(`${f3}${chalk.white(` loaded`)}`));
    bot.commands.set(props.config.name, props);
    props.config.aliases.forEach(alias => {
      bot.aliases.set(alias, props.config.name)
    });
  });
});

fs.readdir("./commands/support/", (err, files) => {
  if(err) console.log(err);
  let jsfile = files.filter(f4 => f4.split(".").pop() === "js");
  if(jsfile.length <= 0){
    console.log("Couldn't find commands.");
    return;
  }
  jsfile.forEach((f4, i) =>{
    let props = require(`./commands/support/${f4}`);
//    console.log(chalk.red(`${f4}${chalk.white(` loaded`)}`));
    bot.commands.set(props.config.name, props);
    props.config.aliases.forEach(alias => {
      bot.aliases.set(alias, props.config.name)
    })
  });
});

fs.readdir("./commands/core/", (err, files) => {
  if(err) console.log(err);
  let jsfile = files.filter(f => f.split(".").pop() === "js");
  if(jsfile.length <= 0){
    return;
  }
  jsfile.forEach((f, i) =>{
    let props = require(`./commands/core/${f}`);
    console.log(`${f} loaded from folder: core`);
    bot.commands.set(props.config.name, props);
    props.config.aliases.forEach(alias => {
      bot.aliases.set(alias, props.config.name)
    })
  });
});
let y = process.openStdin()
y.addListener("data", res => {
  let x = res.toString().trim().split(/ +/g)
  bot.channels.get("582964119456448526").send(x.join(" "))
})

bot.on("ready", async () => {

     bot.user.setActivity(`Josh | ${config.prefix + "help"}`, {type: "WATCHING"});

     setTimeout(async function() {
       console.log(chalk.white(`[${chalk.green(`INFO`)}${chalk.white(`] - Connecting...`)}`));
       }, ms('0.5s'));
     setTimeout(async function() {
       console.log(chalk.white(`[${chalk.green(`INFO`)}${chalk.white(`] - Logged in as: ${bot.user.tag}`)}`));
       }, ms('1s'));
     setTimeout(async function() {
       console.log(chalk.white(`[${chalk.green(`INFO`)}${chalk.white(`] - Online in ${bot.guilds.size} servers!`)}`));
       }, ms('1.5s'));
     setTimeout(async function() {
       console.log(chalk.white(`[${chalk.red(`INFO`)}${chalk.white(`] - Bot is fully loaded up`)}`));
       }, ms('2s'));

     bot.setInterval(() => {
       for(let i in bot.mutes) {
         let time = bot.mutes[i].time;
         let guildId = bot.mutes[i].guild;
         let guild = bot.guilds.get(guildId);
         let member = guild.members.get(i);
         let mutedRole = guild.roles.find(r => r.name === "Muted");
         if(!mutedRole) continue;

         if(Date.now() > time) {
           member.removeRole(mutedRole);
           delete bot.mutes[i];

           fs.writeFile("./storage/mutes.json", JSON.stringify(bot.mutes), err => {
             if(err) throw err;
             console.log(`${member.user.tag} has been unmuted`)
           })
         }
       }
     }, 5000)

     console.log("");

});
   // bot.on('guildMemberAdd', member => {
   //
   //   let channel = member.guild.channels.find(c => c.name === "welcome");
   //       if (!channel) return;
   //  let embed3 = new Discord.RichEmbed()
   //      .setColor("#e50914")
   //      .setTimestamp()
   //      .setThumbnail(logo)
   //      .addField(`Welcome ${member.user.username} to **Arcadewars**!`,`• Enjoy your stay!\n• IP: **arcadewars.net**\n• Store: **https://buy.arcadewars.net/**\n• Discord: **https://discord.gg/ZqJGzb**`)
   //
   //
   //  .setThumbnail(logo)
   //
   //   channel.send(embed3);
   // });

bot.on("message", async message => {

 // if(!message.content.startsWith(config.prefix)) return;
  if(message.author.bot) return;
  if (message.channel.type === "dm") return;


    let prefixes = JSON.parse(fs.readFileSync("./storage/prefixes.json", "utf8"));
    if (!prefixes[message.guild.id]) {
      prefixes[message.guild.id] = {
        prefixes: config.prefix
      };
    }
    let prefix = prefixes[message.guild.id].prefixes;

  let messageArray = message.content.split(" ");
  let cmd = messageArray[0];
  let args = messageArray.slice(1);
  if(!message.content.startsWith(prefix)) return;
  let commandfile = bot.commands.get(cmd.slice(prefix.length)) || bot.commands.get(bot.aliases.get(cmd.slice(prefix.length)));
  if(commandfile) commandfile.run(bot,message,args);

  })

bot.login(config.token)
