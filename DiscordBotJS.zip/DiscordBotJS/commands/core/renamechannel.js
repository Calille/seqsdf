const Discord = require('discord.js');

module.exports.run = (client, message, args) => {

    errorChannel = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to specify a new channel name.")
        .setDescription("Proper usage -rename (channelname)")
    errorTicket = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("This is not a ticket!")
        .setDescription("Proper usage -rename (channelname)")
    errorStaff= new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to be a Staff Member in the discord.")
    errorRole = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to create a `Staff` Role!")
    errorSRole = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to create a `Senior Staff` Role!")

    for (let i in client.tickets) {
        if (message.channel.id !== i) return message.channel.send(errorTicket);
    }
    let sRole = message.guild.roles.find(r => r.name === "Staff");
    let srRole = message.guild.roles.find(r => r.name === "Senior Staff");
    if (!sRole) return message.channel.send(errorRole)
    if (!srRole) return message.channel.send(errorSRole)
    if (!message.member.roles.has(sRole.id) && !message.member.roles.has(srRole.id)) return message.channel.send(errorStaff);

    let channelname = args[0]
    channelRename = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor(`You have successfully renamed the channel to ${channelname}`)

    if (!channelname) {
        message.channel.send(errorChannel)
        return
    }

    message.channel.setName(channelname)
    message.channel.send(channelRename)
}
module.exports.config = {
        name: "rename",
        aliases: ["renamechannel"],
        usage: "-rename <channelname>",
        description: ["Renames a channel to a different name"],
        accessableby: "Staff Members"
}