const Discord = require('discord.js');
const ms = require('ms');
const chalk = require("chalk");
const fs = module.require("fs");

module.exports.run = (client, message, args) => {
    errorStaff = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("Only a `Senior Staff` may proccess this command!")
    errorSyntax = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("Incorrect usage of the command!")
        .setDescription(`-blacklist <user> <category> \n Categories are tickets, suggestions and all`)
    errorRole = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to create a `Staff` and `Senior Staff` Role!")
    worked = new Discord.RichEmbed()
        .setColor("GREEN")
        .setAuthor(`User has been blacklisted from *${args[1]}*`)

    let sRole = message.guild.roles.find(r => r.name === "Staff");
    let srRole = message.guild.roles.find(r => r.name === "Senior Staff");
    if (!sRole || !srRole) return message.channel.send(errorRole) //checks if a staff or senior staff role exist
    if (!message.member.roles.has(sRole.id) || !message.member.roles.has(srRole.id)) return message.channel.send(errorStaff);  //checks if they have staff

    if (args.length <= 1) return message.channel.send(errorSyntax)
    if (!message.mentions.users.first() && !message.guild.members.get(args[0])) return message.channel.send(errorSyntax) //checks if they mention someone

    let blacklisteduser = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));

    if (args[1] === "suggestions") {
        if (client.blacklist[blacklisteduser.id]) {
        for (let i in client.blacklist) {
            let blacklisttype = client.blacklist[i].blacklisttype
            if (blacklisttype === "tickets" || blacklisttype === "all") {
                client.blacklist[blacklisteduser.id] = {
                    blacklisttype: "all"
                }
//                console.log("user is now blacklisted from all")
            } else {
//                console.log("user is blacklisted from suggestions already")
            }
        }} else {
            client.blacklist[blacklisteduser.id] = {
                blacklisttype: "suggestions"
            }
//            console.log("added new user")
        }
        writefile()
    } else if (args[1] === "tickets") {
        if (client.blacklist[blacklisteduser.id]) {
            for (let i in client.blacklist) {
                let blacklisttype = client.blacklist[i].blacklisttype
                if (blacklisttype === "suggestions" || blacklisttype === "all") {
                    client.blacklist[blacklisteduser.id] = {
                        blacklisttype: "all"
                    }
//                    console.log("user is now blacklisted from all")
                } else {
//                    console.log("user is blacklisted from tickets already")
                }
            }} else {
            client.blacklist[blacklisteduser.id] = {
                blacklisttype: "tickets"
            }
//            console.log("added new user")
        }
        writefile()
    } else if (args[1] === "all") {
        client.blacklist[blacklisteduser.id] = {
            blacklisttype: "all"
        }
//        console.log("added new user")
        writefile()
    } else message.channel.send(errorSyntax)

    function writefile() {
    fs.writeFile("./storage/blacklists.json", JSON.stringify(client.blacklist, null, 4), err => {
        if (err) throw err;
        message.channel.send(worked)
    });
}
}
module.exports.config = {
    name: 'blacklist',
    aliases: ["blacklistuser"],
    usage: "-blacklist <user> <subject>",
    description: ["Blacklists a user from either tickets or suggestions"],
    accessableby: "Staff Members"
}
