const Discord = require("discord.js");
const ms = require('ms')
var logo = "https://cdn.discordapp.com/attachments/552318512316678165/567450681208995860/aw.png";
const chalk = require("chalk");

module.exports.run = async (bot, message, args) => {
  function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }
  const useruser = message.author.username;
  const userurl = message.author.avatarURL;

  const embeddefault = new Discord.RichEmbed()
      .setTimestamp()
      .setColor("#e50914")
      .setDescription('Incorrect usage: -bug (server) (issue)')
      .setFooter(useruser, userurl)

  let serverlist = [
    "Skyblock",
    "Factions",
    "Sonic",
    "Mario",
    "Both",
  ];

  if (!args[0]) return message.channel.send(embeddefault)
  let server = capitalizeFirstLetter(args[0]);
  let servertrue = serverlist.includes(server);
  if (!servertrue) return message.channel.send({embed: embeddefault});
  let reportchannel = message.guild.channels.find(c => c.name === "bugreports");
  if (!reportchannel) return message.channel.send("A bug reports channel has not been specified!")
  let bug = args.splice(1).join(' ');
  if (!bug) return message.channel.send({embed: embeddefault});
  message.delete()

  let created = new Discord.RichEmbed()
      .setColor("PURPLE")
      .setAuthor("Bug report created! Our higher staff have been notified!")
  message.channel.send(created)

  let embed = new Discord.RichEmbed()
      .setColor("PURPLE")
      .addField("Bug Report", "Submitted by " + `${message.author}`)
      .addField(`Reported on ${capitalizeFirstLetter(server)} Realm(s)`, `${bug}`)
      .setTimestamp()
      .setFooter(useruser, userurl)
  reportchannel.send({
    embed: embed
  })
  setTimeout(async function() {
    console.log(chalk.white(`[${chalk.green(`BUG REPORT`)}${chalk.white(`] - New report created`)}`));
  }, ms('1s'));

}
module.exports.config = {
  name: "bug",
  aliases: ["bugreport"],
  usage: "-suggest <server> <suggestion>",
  description: ["Makes a bug report for admins+ to view"],
  accessableby: "Members"
}