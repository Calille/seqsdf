const Discord = require('discord.js');

module.exports.run = (client, message, args, guild) => {

    let admin = message.member.hasPermission(8)

    errorAdmin = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to be an admin in the discord.")
        .setDescription("Proper usage .evidence @user (ign)")

    errorMention = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to mention a user.")
        .setDescription("Proper usage .evidence @user (ign)")

    errorUsername = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to mention a username.")
        .setDescription("Proper usage .evidence @user (ign)")

    if (!admin) {
        message.channel.send(errorAdmin);
        return
    }

    let userName = args[1]

    if (!userName) {
        message.channel.send(errorUsername);
        return
    }

    let dUser = message.guild.member(message.mentions.users.first())
    let role = message.guild.roles.find(r => r.name === "Sr. Mod");
    let role3 = message.guild.roles.find(r => r.name === 'Admin');
    let role4 = message.guild.roles.find(r => r.name === 'Sr. Admin');
    let role2 = message.guild.roles.find(r => r.name === '@everyone');

    function createevidencechannel() {
        message.guild.createChannel(userName, "text").then(c => {
            c.overwritePermissions(role, {
                SEND_MESSAGES: true,
                READ_MESSAGES: true
            });
            c.overwritePermissions(role2, {
                SEND_MESSAGES: false,
                READ_MESSAGES: false
            });
            c.overwritePermissions(role3, {
                SEND_MESSAGES: true,
                READ_MESSAGES: true
            });
            c.overwritePermissions(role4, {
                SEND_MESSAGES: true,
                READ_MESSAGES: true
            });
            c.overwritePermissions(dUser, {
                SEND_MESSAGES: true,
                READ_MESSAGES: true
            });
            const ticketEmbed = new Discord.RichEmbed()
                .setAuthor("Welcome to the ArcadeWars Staff Team!")
                .setThumbnail(`${message.author.avatarURL}`)
                .setColor("#e50914")
                .setDescription("Welcome to the Staff Team, before punishing players we require you to read the following staff guide.\nhttp://bit.ly/staffguidearcadewars\nWe also require you to log all of your punishments using this format:\n\nIGN:\nUniverse:\nType (Ban/Mute):\nReason:\nProof:", true)
            c.send({embed: ticketEmbed});

            const categoryId = "560561424745758738";
            c.setParent(categoryId)

            embedcreate = new Discord.RichEmbed()
                .setColor("#e50914")
                .setAuthor("Done")
                .setDescription(`You successfully created an evidence channel. See ${userName}.`)

            message.channel.send(embedcreate);
            return;
        }).catch(console.error);
    }

    if (!dUser) {
        message.channel.send(errorMention);
        return
    }

    createevidencechannel()
}
module.exports.config = {
    name: "evidencechannel",
    aliases: [""],
    usage: ".evidencechannel <user> <IGN>",
    description: ["Opens a staff evidence channel for a new staff member"],
    accessableby: "Staff Members"
}