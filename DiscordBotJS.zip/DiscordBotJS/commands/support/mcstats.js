var Discord = require('discord.js')
var request = require('request');

var mcIP = 'arkhamnetwork.org';
var mcPort = 25565; 
var logo = "https://cdn.discordapp.com/attachments/552318512316678165/567450681208995860/aw.png";
module.exports.run = (client, message, args) => {
    
        var url = 'http://mcapi.us/server/status?ip=' + mcIP + '&port=' + mcPort;
        request(url, function(err, response, body) {
            if(err) {
                console.log(err);
                return message.reply('Error getting Minecraft server status...');
            }
            body = JSON.parse(body);
            var status = '*ArkhamNetwork is currently offline*';
            if(body.online) {
                status = 'ArcadeWars is online  -  ',"Join arkhamnetwork.org to start your adventure!";
                if(body.players.now) {
                    status += '' + body.players.now + ' people are playing!','Join arkhamnetwork.org to start your adventure!';
                } else {
                    status += '*Nobody is playing!*';
                }
            }
            const embed = new Discord.RichEmbed()
.setColor("#e50914")
            .setAuthor(status)
            .setFooter('Join arkhamnetwork.org to start your adventure now! ')
            message.channel.send({embed: embed});
        });
    }

module.exports.config = {
    name: "server",
    aliases: ["arkham"],
    usage: ".server",
    description: ["Shows the number of players on the server"],
    accessableby: "Members"
}