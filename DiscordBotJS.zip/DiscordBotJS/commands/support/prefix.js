const Discord = require("discord.js");
const fs = require("fs");

module.exports.run = async (bot, message, args) => {

    const useruser = message.author.username;
    const userurl = message.author.avatarURL;

    if(!message.member.hasPermission("MANAGE_SERVER")) return message.reply("You have insufficient permissions");
    if(!args[0] || args[0 == "help"]) return message.reply("Incorrect usage, specify a new prefix");

    let prefixes = JSON.parse(fs.readFileSync("./storage/prefixes.json", "utf8"));

    prefixes[message.guild.id] = {
        prefixes: args[0],
    }
    fs.writeFile("./storage/prefixes.json", JSON.stringify(prefixes), (err) => {
        if (err) console.log(err)
    });

    let sEmbed = new Discord.RichEmbed()
        .setColor("#e50914")
        .setTitle("Prefix Set!")
        .setDescription(`Set to ${args[0]}`)
        .setFooter(useruser, userurl)

    message.channel.send(sEmbed)
};
module.exports.config = {
    name: "prefix",
    aliases: ["setprefix"],
    usage: ".setprefix <prefix>",
    description: ["Sets a new prefix for this guild"],
    accessableby: "Staff Members"
}
