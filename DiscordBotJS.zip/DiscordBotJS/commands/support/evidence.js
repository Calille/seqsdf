const Discord = require('discord.js')
var logo = "https://cdn.discordapp.com/attachments/552318512316678165/567450681208995860/aw.png";

module.exports.run = async (bot, message, args) => {

    let punishmentchannel = message.guild.channels.find(c => c.name === "media");
    if (!punishmentchannel) return;
    let testserver = "582963963814346762";
    let arkhamstaffdiscord = "398232342965125120";

    if(!message.guild.id === testserver || !message.guild.id === arkhamstaffdiscord) return;

    const useruser = message.author.username;
    const userid = message.author.discriminator;
    const userurl = message.author.avatarURL;

    const filter = m => m.author.id === message.author.id;

    let username = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("Please choose a username of the player you have punished.")
        .setFooter(useruser, userurl)

    message.channel.send(username).then(r => r.delete(60000));
    message.channel.awaitMessages(filter, {max: 1, time:60000}).then(collected => {
        if(collected.first().content === "cancel") {
            return message.reply("Canceled!");
        }
        let ign = collected.first().content;
        let banormute = new Discord.RichEmbed()
            .setColor("#e50914")
            .setAuthor("Did you ban or mute the player and for how long (14d Mute/Perm Ban)?")
            .setFooter(useruser, userurl)
        message.channel.send(banormute).then(r => r.delete(60000));
        message.channel.awaitMessages(filter, {max: 1, time: 60000}).then(collected => {
            if(collected.first().content === "cancel") {
                return message.reply("Canceled!");
            }
            let punishmenttype = collected.first().content;
            let reason = new Discord.RichEmbed()
                .setColor("#e50914")
                .setAuthor("What was the reason you punished this player?")
                .setFooter(useruser, userurl)
            message.channel.send(reason).then(r => r.delete(60000));
            message.channel.awaitMessages(filter, {max: 1, time: 60000}).then(collected => {
                if(collected.first().content === "cancel") {
                    return message.reply("Canceled!");
                }
                let punishmentreason = collected.first().content;
                let proof = new Discord.RichEmbed()
                    .setColor("#e50914")
                    .setAuthor("Submit the proof you have for this (use links only)")
                    .setFooter(useruser, userurl)
                message.channel.send(proof).then(r => r.delete(60000));
                message.channel.awaitMessages(filter, {max: 1, time: 60000}).then(collected => {
                    if(collected.first().content === "cancel") {
                        return message.reply("Canceled!");
                    }
                    let evidence = collected.first().content;
                    let punishmentembed = new Discord.RichEmbed()
                        .setColor("#e50914")
                        .addField("Punishment issued by " + `${message.author.username}`, ign + " has been given a " + punishmenttype)
                        .addField("For '" + punishmentreason + "'", evidence)
                        .setFooter(useruser + "#" + userid, userurl)
                    let punishmentchannel = message.guild.channels.find(c => c.name === "media");
                    punishmentchannel.send(punishmentembed)
                    //     .then(function(message) {
                    //     setTimeout(function() {
                    //         message.react("🚫");
                    //     }, ms("1s"));
                    // }).catch(function() {
                    // });
                    // setTimeout(async function() {
                    //     console.log(chalk.white(`[${chalk.green(`SUGGESTION`)}${chalk.green(`] - New punishment created`)}`));
                    // }, ms('1s'));
                })
            })
        })
    })

}
module.exports.config = {
    name: "evidence",
    aliases: ["e"],
    usage: ".evidence",
    description: ["Allows you to post evidence in the staff discord"],
    accessableby: "Staff Members"
}