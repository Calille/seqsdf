const Discord = require('discord.js')
var logo = "https://cdn.discordapp.com/attachments/552318512316678165/567450681208995860/aw.png";
const ms = require('ms')
const chalk = require("chalk");

module.exports.run = async (bot, message, args) => {

    let inactivitychannel = message.guild.channels.find(c => c.name === "staff-away");
    if (!inactivitychannel) return;
    let testserver = "582963963814346762";
    let arkhamstaffdiscord = "398232342965125120";
    if(!message.guild.id === testserver || !message.guild.id === arkhamstaffdiscord) return;

    const useruser = message.author.username;
    const userid = message.author.discriminator;
    const userurl = message.author.avatarURL;

    const filter = m => m.author.id === message.author.id;

    let username = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("What is your ingame name?")
        .setFooter(useruser, userurl)

    message.channel.send(username).then(r => r.delete(60000));
    message.channel.awaitMessages(filter, {max: 1, time:60000}).then(collected => {
        if (collected.first().content === "cancel") {
            return message.reply("Canceled!");
        }
        let ign = collected.first().content;
        let offline = new Discord.RichEmbed()
            .setColor("#e50914")
            .setAuthor("Are you going to be offline or inactive?")
            .setFooter(useruser, userurl)
        message.channel.send(offline).then(r => r.delete(60000));
        message.channel.awaitMessages(filter, {max: 1, time: 60000}).then(collected => {
            if (collected.first().content === "cancel") {
                return message.reply("Canceled!");
            }
            let inactivitytype = collected.first().content;
            let startdate = new Discord.RichEmbed()
                .setColor("#e50914")
                .setAuthor("What date are you leaving on? (DD/MM/YY)")
                .setFooter(useruser, userurl)
            message.channel.send(startdate).then(r => r.delete(60000));
            message.channel.awaitMessages(filter, {max: 1, time: 60000}).then(collected => {
                if (collected.first().content === "cancel") {
                    return message.reply("Canceled!");
                }
                let startdateresponse = collected.first().content;
                let enddate = new Discord.RichEmbed()
                    .setColor("#e50914")
                    .setAuthor("What date are you arriving on? (DD/MM/YY)")
                    .setFooter(useruser, userurl)
                message.channel.send(enddate).then(r => r.delete(60000));
                message.channel.awaitMessages(filter, {max: 1, time: 60000}).then(collected => {
                    if (collected.first().content === "cancel") {
                        return message.reply("Canceled!");
                    }
                    let enddateresponse = collected.first().content;
                    let reason = new Discord.RichEmbed()
                        .setColor("#e50914")
                        .setAuthor("Why are you going to be away?")
                        .setFooter(useruser, userurl)
                    message.channel.send(reason).then(r => r.delete(60000));
                    message.channel.awaitMessages(filter, {max: 1, time: 60000}).then(collected => {
                        if (collected.first().content === "cancel") {
                            return message.reply("Canceled!");
                        }
                        let reasonresponse = collected.first().content;
                        let inactivityform = new Discord.RichEmbed()
                            .setColor("#e50914")
                            .setAuthor(ign + "'s Absence note")
                            .setDescription(`**Inactive/Offline:** ${inactivitytype}\n**Starting date:** ${startdateresponse}\n**Ending date:** ${enddateresponse}\n**Reason:** ${reasonresponse}`)
                            .setFooter(useruser + "#" + userid, userurl)
                            .setTimestamp()
                        let inactivitychannel = message.guild.channels.find(c => c.name === "staff-away");
                        inactivitychannel.send(inactivityform)
                        //     .then(function(message) {
                        //     setTimeout(function() {
                        //         message.react("🚫");
                        //     }, ms("1s"));
                        // }).catch(function() {
                        // });
                        // setTimeout(async function() {
                        //     console.log(chalk.white(`[${chalk.green(`SUGGESTION`)}${chalk.green(`] - New punishment created`)}`));
                        // }, ms('1s'));
                    })
                })
            })
        })
    })

}
module.exports.config = {
    name: "inactivity",
    aliases: ["inactive"],
    usage: ".inactivity",
    description: ["Posts an inactivity form"],
    accessableby: "Staff Members"
}