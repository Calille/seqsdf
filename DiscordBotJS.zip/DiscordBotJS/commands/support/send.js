const Discord = require('discord.js')



module.exports.run = (client, message, args) => {

    let admin = message.member.hasPermission(8)

    errorMention = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to mention a user.")
        .setDescription("Proper usage .send @user (message)")

    errorReason = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to mention a message.")
        .setDescription("Proper usage .send @user (message)")

    errorAdmin = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to be an admin in the discord.")
        .setDescription("Proper usage .send @user (message)")

    if (!admin) {
        message.channel.send(errorAdmin);
        return
    }
    let dUser = message.guild.member(message.mentions.users.first())
    let dMessage = args.splice(1).join(' ');

    if (!dUser) {
        message.channel.send(errorMention);
        return
    }
    if (!dMessage) {
        message.channel.send(errorReason);
        return
    }
    dUser.send(`You have been send the following message: \n\`${dMessage}\``)

    message.channel.send(`${message.author} You have sent your message to ${dUser}`)
}

module.exports.config = {
    name: "send",
    aliases: ["message"],
    usage: ".send <user> <message>",
    description: ["Sends a user a message through the bot"],
    accessableby: "Staff Members"
}
