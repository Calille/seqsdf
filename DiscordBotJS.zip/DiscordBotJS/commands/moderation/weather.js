const Discord = require('discord.js');
const weather = require('weather-js');
var logo = "https://cdn.discordapp.com/attachments/651502289944838156/651739022267252746/picturetopeople.org-2ef0a294356bf2936f715993160195c1a7d9a8c37dd224bc2a.png";

module.exports.run = (bot, message, args) => {
    const city = message.content.split(" ").slice(1).join(" ")
    if (!city) return message.channel.send("**Error**\nYou did not include a city! Please include it so we can show the weather!")

    weather.find({search: city, degreeType: 'C'}, function(err, result) {
        if (err) {
            message.channel.send(":x: No results on that city :x:")
            console.log(err.stack)
            return;
        } 
        let url;
        if (result[0].current.skytext === "Mostly Sunny") url = "https://openclipart.org/image/2400px/svg_to_png/3367/ivak-Decorative-Sun.png"
        else if (result[0].current.skytext === "Mostly Cloudy" || result[0].current.skytext === "Cloudy") url = "https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Weather-heavy-overcast.svg/200px-Weather-heavy-overcast.svg.png"
        else if (result[0].current.skytext === "Partly Cloudy") url = "";
       // message.channel.send(JSON.stringify(result[0].current, null, 2))
        var embed = new Discord.RichEmbed()
        .setTitle(`Forecast for ${result[0].location.name}`)
        .setColor("#e50914")
        .setThumbnail(logo)
        .setTimestamp()
        .addField("Temperature:", `**__${result[0].current.temperature}__ Degrees**`)
        .addField("What it looks like outside:", `**__${result[0].current.skytext}__**`)
        .addField("Feels Like", `**__${result[0].current.feelslike}__ Degrees**`)
        .addField("Humidity", `**__${result[0].current.humidity}%__**`)
        .addField("Wind Speed", `**__${result[0].current.windspeed.replace("mph", "Miles Per Hour")}__**`)
        message.channel.send({ embed: embed })
});
}


module.exports.config = {
    name: "weather",
    aliases: [],
    usage: ".weather <location>",
    description: ["Shows the weather for that location"],
    accessableby: "Members"
}