      
const Discord = require('discord.js');
var logo = "https://cdn.discordapp.com/attachments/651502289944838156/651739022267252746/picturetopeople.org-2ef0a294356bf2936f715993160195c1a7d9a8c37dd224bc2a.png";
module.exports.run = async (client, message, args) => {
    if (!message.member.hasPermission(8)) {
		const embed2 = new Discord.RichEmbed()
		.setTimestamp()
		.setColor("#e50914")
		.setThumbnail(logo)
		.setDescription('You are missing permission: `ADMINISTRATOR` to be able to execute this command!')
			 message.channel.send({embed: embed2})
		} else {

    let args = message.content.split(" ").slice(1);
let status = args.join(' ')


client.user.setActivity(status)
const embed2 = new Discord.RichEmbed()
.setTimestamp()
		.setColor("#e50914")
		.setThumbnail(logo)
		.setDescription(`Status set to: ${status}`)
			 message.channel.send({embed: embed2})
}
}
module.exports.config = {
	name:"setstatus",
	aliases: ["botstatus"],
	usage: ".setstatus <status>",
    description: ["Sets the bots activity"],
    accessableby: "Staff Members"
}