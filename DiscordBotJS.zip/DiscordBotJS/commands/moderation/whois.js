const Discord = require('discord.js')
var logo = "https://cdn.discordapp.com/attachments/651502289944838156/651739022267252746/picturetopeople.org-2ef0a294356bf2936f715993160195c1a7d9a8c37dd224bc2a.png";
module.exports.run = (client, message, args) => {


  const moment = require("moment");
  let user = message.mentions.members.first();

  errorMention = new Discord.RichEmbed()
      .setColor("#e50914")
      .setAuthor("You need to specify a user")
      .setDescription("Proper usage .whois @user")

  if (!user) {
    message.channel.send(errorMention)
    return
  }
  const member = message.guild.member(user);
  let target = message.author.id
  let embed = new Discord.RichEmbed()
    .setColor("#e50914")
    .setThumbnail(logo)
    .addField("ID:", `${user.id}`, true)
    .addField("Nickname:", `${member.nickname !== null ? `${member.nickname}` : 'None'}`, true)
    .addField("Join Position:", `${message.guild.members.sort((m1, m2) => m1.joinedTimestamp - m2.joinedTimestamp).array().indexOf(message.mentions.members.first()) + 1}`, true)
    .addField("Bot:", `${client.user.username}`, true)
    .addField("Status:", `${user.presence.status}`, true)
    .addField("Game:", `${user.presence.game ? user.presence.game.name : 'None'}`, true)
    .addField("Roles:", member.roles.map(roles => `${roles.name}`).join(', '), true)
    .setFooter(`Replying to ${message.author.username}#${message.author.discriminator}`)
  message.channel.send({embed: embed})
}
module.exports.config = {
  name: "whois",
  aliases: [],
  usage: ".whois <user>",
  description: ["Gives you some infomation about a user"],
  accessableby: "Members"
}