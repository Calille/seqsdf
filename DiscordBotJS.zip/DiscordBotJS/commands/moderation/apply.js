const Discord = require("discord.js");
var logo = 'https://cdn.discordapp.com/attachments/651502289944838156/651739022267252746/picturetopeople.org-2ef0a294356bf2936f715993160195c1a7d9a8c37dd224bc2a.png'
module.exports.run = (client, message, args) => {

    let testEmbed = new Discord.RichEmbed()
    .setAuthor("TEST Application Links!")
    .setColor("#e50914")
    .setThumbnail(logo)
    .addField("Staff Application", "N/A")
    .addField("YouTuber Application", "N/A")
    .addField("Discord DJ Application", "N/A");

    let arcadeEmbed = new Discord.RichEmbed()
        .setAuthor("Arcade Application Links!")
        .setColor("#e50914")
        .setThumbnail(logo)
        .addField("Staff Application", "N/A")
        .addField("YouTuber Application", "N/A")
        .addField("Discord DJ Application", "N/A");

    let arkhamEmbed = new Discord.RichEmbed()
        .setAuthor("Arkham Application Links!")
        .setColor("#e50914")
        .setThumbnail(logo)
        .addField("Staff Application", "N/A")
        .addField("YouTuber Application", "N/A")
        .addField("Discord DJ Application", "N/A");

    if (message.guild.id === "582963963814346762") {
        message.channel.send(testEmbed)
    }
    if (message.guild.id === "275779985728602112") {
        message.channel.send(arcadeEmbed)
    }
    if (message.guild.id === "198961272933449737") {
        message.channel.send(arkhamEmbed)
    }

}    


module.exports.config = {
    name: "apply",
    aliases: ["staff"],
    usage: ".apply",
    description: ["A few links to applications on our website"],
    accessableby: "Members"
}