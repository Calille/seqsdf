var logo = "https://cdn.discordapp.com/attachments/651502289944838156/651739022267252746/picturetopeople.org-2ef0a294356bf2936f715993160195c1a7d9a8c37dd224bc2a.png";
var Discord = require('discord.js')



module.exports.run = (bot, message, args) => {

  if (!message.member.hasPermission('MANAGE_NICKNAMES')) {
    const embed2 = new Discord.RichEmbed()
      .setTimestamp()
      .setColor("#e50914")
      .setThumbnail(logo)
      .setDescription('You are missing permission: `MANAGE_NICKNAMES` to be able to execute this command!')
    message.channel.send({
      embed: embed2
    })
  } else {

    let user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]))
    if (!user) return message.channel.send("Please mention someone!")
    let nickname = args.join(" ").slice(22)
    if(!nickname) return message.channel.send("Please specify a nickname!")
    

    user.setNickname(nickname)
    message.reply("Done! Set users nickname to: " + `**${nickname}**`)


  }

}
module.exports.config = {
  name: "nick",
  aliases: ["nickname", "setnick"],
  usage: ".nick <user> <nick>",
  description: ["Changes a users nickname"],
  accessableby: "Staff Members"
}