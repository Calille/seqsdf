const Discord = require('discord.js');

module.exports.run = (client, message, args) => {

    errorChannel = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to specify a channel.")
        .setDescription("Proper usage .rename (channelname)")

    errorTicket = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("This is not a ticket!")
        .setDescription("Proper usage .rename (channelname)")

    errorStaff= new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to be a Staff Member in the discord.")
        .setDescription("Proper usage .rename (channelname)")

    let sRole = message.guild.roles.find(r => r.name === "Staff Member");
    if (!message.member.roles.has(sRole.id)) return message.channel.send(errorStaff);

    for (let i in client.tickets) {
        if (message.channel.id !== i) return message.channel.send("This is not a ticket!");
    }
    let channelname = args[0]

    channelRename = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor(`You have successfully renamed the channel to ${channelname}`)

    if (!channelname) {
        message.channel.send(errorChannel)
        return
    }

    message.channel.setName(channelname)
    message.channel.send(channelRename)
}
module.exports.config = {
        name: "rename",
        aliases: ["renamechannel"],
        usage: ".rename <channelname>",
        description: ["Renames a channel to a different name"],
        accessableby: "Staff Members"
}