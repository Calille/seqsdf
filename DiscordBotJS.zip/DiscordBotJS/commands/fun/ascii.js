const figlet = require('figlet');

module.exports.run = async (bot, message, args) => {
    if (!args.join (' ')) return message.channel.send('Please provide text!');
    figlet(args.join(' '), (err, data) => {
        message.channel.send(data, {
            code: 'ascii'
        });
    });
};
module.exports.config = {
    name: "ascii",
    aliases: ["asc"],
    usage: ".ascii <text>",
    description: ["Converts standard text to ascii font"],
    accessableby: "Members"
}
