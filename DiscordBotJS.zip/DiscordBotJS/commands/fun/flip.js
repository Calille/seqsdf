const Discord = require('discord.js');



module.exports.run = (client, message, args) => {

var hd = [
    "Heads",
    "Tails"
];
  message.channel.send(message.author.toString() + " You flipped: " + (hd[Math.floor(Math.random() * hd.length)]));
}

module.exports.config = {
    name: "flip",
    aliases: ["coinflip"],
    usage: ".flip",
    description: ["Flips a coin"],
    accessableby: "Members"
}
